<?php
// This file declares an Angular module which can be autoloaded
// in CiviCRM. See also:
// \https://docs.civicrm.org/dev/en/latest/hooks/hook_civicrm_angularModules/n
return [
  'js' => [
    'ang/civixsnapshot.js',
    'ang/civixsnapshot/*.js',
    'ang/civixsnapshot/*/*.js',
  ],
  'css' => [
    'ang/civixsnapshot.css',
  ],
  'partials' => [
    'ang/civixsnapshot',
  ],
  'requires' => [
    'crmUi',
    'crmUtil',
    'ngRoute',
  ],
  'settings' => [],
];
