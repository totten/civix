(function(angular, $, _) {
  // Declare a list of dependencies.
  angular.module('civixsnapshot', CRM.angRequires('civixsnapshot'));
})(angular, CRM.$, CRM._);
