<?php
// phpcs:disable
use CRM_Civixsnapshot_ExtensionUtil as E;
// phpcs:enable

class CRM_Civixsnapshot_BAO_MyEntityThreeFour extends CRM_Civixsnapshot_DAO_MyEntityThreeFour {

  /**
   * Create a new MyEntityThreeFour based on array-data
   *
   * @param array $params key-value pairs
   * @return CRM_Civixsnapshot_DAO_MyEntityThreeFour|NULL
   */
  /*
  public static function create($params) {
    $className = 'CRM_Civixsnapshot_DAO_MyEntityThreeFour';
    $entityName = 'MyEntityThreeFour';
    $hook = empty($params['id']) ? 'create' : 'edit';

    CRM_Utils_Hook::pre($hook, $entityName, CRM_Utils_Array::value('id', $params), $params);
    $instance = new $className();
    $instance->copyValues($params);
    $instance->save();
    CRM_Utils_Hook::post($hook, $entityName, $instance->id, $instance);

    return $instance;
  }
  */

}
