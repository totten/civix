<?php
// phpcs:disable
use CRM_Civixsnapshot_ExtensionUtil as E;
// phpcs:enable

class CRM_Civixsnapshot_BAO_MyEntityFour extends CRM_Civixsnapshot_DAO_MyEntityFour {

  /**
   * Create a new MyEntityFour based on array-data
   *
   * @param array $params key-value pairs
   * @return CRM_Civixsnapshot_DAO_MyEntityFour|NULL
   */
  /*
  public static function create($params) {
    $className = 'CRM_Civixsnapshot_DAO_MyEntityFour';
    $entityName = 'MyEntityFour';
    $hook = empty($params['id']) ? 'create' : 'edit';

    CRM_Utils_Hook::pre($hook, $entityName, CRM_Utils_Array::value('id', $params), $params);
    $instance = new $className();
    $instance->copyValues($params);
    $instance->save();
    CRM_Utils_Hook::post($hook, $entityName, $instance->id, $instance);

    return $instance;
  }
  */

}
