(function(angular, $, _) {
  // Declare a list of dependencies.
  angular.module('crmCivixsnapshot', CRM.angRequires('crmCivixsnapshot'));
})(angular, CRM.$, CRM._);
