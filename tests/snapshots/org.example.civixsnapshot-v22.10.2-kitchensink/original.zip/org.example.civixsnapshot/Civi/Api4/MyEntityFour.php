<?php
namespace Civi\Api4;

/**
 * MyEntityFour entity.
 *
 * Provided by the org.example.civixsnapshot extension.
 *
 * @package Civi\Api4
 */
class MyEntityFour extends Generic\DAOEntity {

}
