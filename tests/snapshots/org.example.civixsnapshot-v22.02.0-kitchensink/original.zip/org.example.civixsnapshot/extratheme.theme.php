<?php
// This file declares a CSS theme for CiviCRM.

return [
  'name' => 'extratheme',
  'title' => 'extratheme theme',
  'prefix' => 'extratheme/',
  'url_callback' => '\\Civi\\Core\\Themes\\Resolvers::simple',
  'search_order' => [
    'extratheme',
    '_fallback_',
  ],
  'excludes' => [],
];
