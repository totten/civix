<?php
namespace Civi\Api4;

/**
 * MyEntityThreeFour entity.
 *
 * Provided by the FIXME extension.
 *
 * @package Civi\Api4
 */
class MyEntityThreeFour extends Generic\DAOEntity {

}
