<?php
// This file declares a CSS theme for CiviCRM.

return [
  'name' => 'civixsnapshot',
  'title' => 'civixsnapshot theme',
  'prefix' => null,
  'url_callback' => '\\Civi\\Core\\Themes\\Resolvers::simple',
  'search_order' => [
    'civixsnapshot',
    '_fallback_',
  ],
  'excludes' => [],
];
