<?php

require_once 'civixsnapshot.civix.php';

use CRM_Civixsnapshot_ExtensionUtil as E;

/**
 * Implements hook_civicrm_config().
 *
 * @link https://docs.civicrm.org/dev/en/latest/hooks/hook_civicrm_config/
 */
function civixsnapshot_civicrm_config(&$config): void {
  _civixsnapshot_civix_civicrm_config($config);
}

/**
 * Implements hook_civicrm_install().
 *
 * @link https://docs.civicrm.org/dev/en/latest/hooks/hook_civicrm_install
 */
function civixsnapshot_civicrm_install(): void {
  _civixsnapshot_civix_civicrm_install();
}

/**
 * Implements hook_civicrm_enable().
 *
 * @link https://docs.civicrm.org/dev/en/latest/hooks/hook_civicrm_enable
 */
function civixsnapshot_civicrm_enable(): void {
  _civixsnapshot_civix_civicrm_enable();
}
