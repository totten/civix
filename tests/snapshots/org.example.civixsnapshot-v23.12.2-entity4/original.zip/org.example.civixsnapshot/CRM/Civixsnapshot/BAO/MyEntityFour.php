<?php

use CRM_Civixsnapshot_ExtensionUtil as E;

class CRM_Civixsnapshot_BAO_MyEntityFour extends CRM_Civixsnapshot_DAO_MyEntityFour {

}
