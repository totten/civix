<?php
// This file declares a CSS theme for CiviCRM.

return array (
  'name' => 'civixsnapshot',
  'title' => 'civixsnapshot theme',
  'prefix' => NULL,
  'url_callback' => '\\Civi\\Core\\Themes\\Resolvers::simple',
  'search_order' => 
  array (
    0 => 'civixsnapshot',
    1 => '_fallback_',
  ),
  'excludes' => 
  array (
  ),
);
