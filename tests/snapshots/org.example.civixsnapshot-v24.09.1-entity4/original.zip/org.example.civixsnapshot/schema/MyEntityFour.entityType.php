<?php
use CRM_Civixsnapshot_ExtensionUtil as E;
return [
  'name' => 'MyEntityFour',
  'table' => 'civicrm_my_entity_four',
  'class' => 'CRM_Civixsnapshot_DAO_MyEntityFour',
  'getInfo' => function() { return [
    'title' => E::ts('MyEntityFour'),
    'title_plural' => E::ts('MyEntityFours'),
    'description' => E::ts('FIXME'),
    'log' => TRUE,
  ]; },
  'getFields' => function() { return [
    'id' => [
      'title' => E::ts('ID'),
      'sql_type' => 'int unsigned',
      'input_type' => 'Number',
      'required' => TRUE,
      'description' => E::ts('Unique MyEntityFour ID'),
      'primary_key' => TRUE,
      'auto_increment' => TRUE,
    ],
    'contact_id' => [
      'title' => E::ts('Contact ID'),
      'sql_type' => 'int unsigned',
      'input_type' => 'EntityRef',
      'description' => E::ts('FK to Contact'),
      'entity_reference' => [
        'entity' => 'Contact',
        'key' => 'id',
        'on_delete' => 'CASCADE',
      ],
    ],
  ]; },
  'getIndices' => function() { return []; },
  'getPaths' => function() { return []; },
];
