<?php
namespace Civi\Api4;

/**
 * MyEntityThreeFour entity.
 *
 * Provided by the org.example.civixsnapshot extension.
 *
 * @package Civi\Api4
 */
class MyEntityThreeFour extends Generic\DAOEntity {

}
