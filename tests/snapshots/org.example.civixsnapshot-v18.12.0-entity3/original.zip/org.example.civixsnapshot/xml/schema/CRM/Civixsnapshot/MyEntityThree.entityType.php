<?php
// This file declares a new entity type. For more details, see "hook_civicrm_entityTypes" at:
// http://wiki.civicrm.org/confluence/display/CRMDOC/Hook+Reference
return array (
  0 => 
  array (
    'name' => 'MyEntityThree',
    'class' => 'CRM_Civixsnapshot_DAO_MyEntityThree',
    'table' => 'civicrm_my_entity_three',
  ),
);
