(function(angular, $, _) {
  // "fooBar" is a basic skeletal directive.
  // Example usage: <div foo-bar="{foo: 1, bar: 2}"></div>
  angular.module('crmCivixsnapshot').directive('fooBar', function() {
    return {
      restrict: 'AE',
      templateUrl: '~/crmCivixsnapshot/fooBar.html',
      scope: {
        fooBar: '='
      },
      link: function($scope, $el, $attr) {
        var ts = $scope.ts = CRM.ts('org.example.civixsnapshot');
        $scope.$watch('fooBar', function(newValue){
          $scope.myOptions = newValue;
        });
      }
    };
  });
})(angular, CRM.$, CRM._);
